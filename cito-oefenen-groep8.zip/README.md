# Cito Oefenen — Groep 8

Korte demo-website om Cito-oefeningen zichtbaar te maken. Deze repository bevat kant-en-klare bestanden die je op GitHub Pages kunt publiceren.

## Inhoud
- `index.html` — startpagina
- `style.css` — styling
- `script.js` — eenvoudige front-end logica

## Publiceren op GitHub Pages
1. Maak een nieuwe repository op GitHub (bijv. `cito-oefenen-groep8`).
2. Upload alle bestanden uit deze map (of push met git).
3. Ga naar **Settings → Pages** en kies de `main` branch en de root `/` als publicatiemap.
4. Na een paar minuten is de site bereikbaar op `https://<jouw-gebruikersnaam>.github.io/<repositorynaam>`.

## Belangrijk
- Deze demo slaat geen echte bestanden op de server op. Voor echte uploads heb je server-side code nodig (bijv. Netlify Functions, Firebase, of een kleine server met Node/Express).
- Gebruik de login-code `15032010661176200642323542` om het upload-paneel te bekijken (demo-code). 

## Aanpassen
Je kunt de thema-lijsten aanpassen in `script.js` of extra pagina's toevoegen.

---
Succes! Als je wilt, kan ik de bestanden voor je zippen en een downloadlink aanmaken.